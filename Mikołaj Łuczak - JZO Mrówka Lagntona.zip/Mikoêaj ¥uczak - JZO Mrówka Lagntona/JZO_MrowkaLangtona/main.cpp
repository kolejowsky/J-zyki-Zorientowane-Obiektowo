


///////////////////////////////////////////////////////////////
//                                                           //
//          Miko�aj �uczak                                   //
//          Jezyki Zorientowane Obiektowo                    //
//          Studia Stacjonarne                               //
//          Grupa 1                                          //
//          Gra mr�wka langtona                              //
//                                                           //
//                                                           //
//                                                           //
//                                                           //
///////////////////////////////////////////////////////////////


#include "gametxt.h"

using namespace std;

int main()
{
    GameTxt g1;         //utworzenie obiektu odpowiedzialnego za gr�
    //g1.play();        //funkcja rozpoczynaj�ca gr� w trybie "klasycznym"
    g1.timelapse();     //funkcja rozpoczynaj�ca gr� w trybie "przyspieszonym"
}


