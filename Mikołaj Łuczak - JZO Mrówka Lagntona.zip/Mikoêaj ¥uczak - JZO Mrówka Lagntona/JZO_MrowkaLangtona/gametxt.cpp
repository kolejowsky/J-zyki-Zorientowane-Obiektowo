#include <iostream>
#include <windows.h>

#include "gametxt.h"

using namespace std;

void GameTxt::show()
{
    //funkcja pomocnicza
    for (int i = 0; i < nk; i++)
    {
        for (int j = 0; j < nw; j++)
        {
            //cout << tab[i][j] << " ";
            if (i == ant_pos_x && j == ant_pos_y)
            {
                cout << "@" << " ";
            }
            else if (tab[i][j])
            {
                cout << "#" << " ";
            }
            else
            {
                cout << " " << " ";
            }

        }
        cout << endl;
    }
}

void GameTxt::view()
{
    system("cls");
    show();
    Sleep(0.1);

}

GameTxt::~GameTxt() {};
