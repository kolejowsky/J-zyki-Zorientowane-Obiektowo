#ifndef ENGINE_H
#define ENGINE_H


class Engine
{
protected:
    bool** tab;
    int nk, nw;
    int ant_pos_x;
    int ant_pos_y;
    enum direction { N = 1, E, S, W };
    int ant_d = N;
protected:
    Engine();
    Engine(int w, int k);
    virtual ~Engine();
    void buildTab();
    void setTab();

    void turn_right();
    void turn_left();
    void move_forward();
    void move();
    void switch_color(int x, int y);
    void analyse();

private:
    Engine(const Engine& e);
    Engine& operator= (const Engine& e);

};

#endif