#ifndef GAME_H
#define GAME_H

#include "engine.h"

class Game : public Engine
{
protected:
    Game() :Engine() {};
    Game(int w, int k) :Engine(w, k) {};
    virtual void view();
public:
    void play();
    void timelapse();
    ~Game();
private:
    Game(const Game& g);
    Game& operator= (const Game& g);
};

#endif
