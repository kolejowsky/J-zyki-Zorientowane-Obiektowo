#include "engine.h"

#include <iostream>
#include <windows.h>

using namespace std;

Engine :: Engine()
{
    //�eby by�o czytelne 40 x 85
    nk = 39;
    nw = 85;
    ant_pos_x = nk / 2;
    ant_pos_y = nw / 2;
    ant_d = N;
    buildTab();
    setTab();
}

Engine :: Engine(int w, int k)
{
    nk = k;
    nw = w;
    ant_pos_x = nk / 2;
    ant_pos_y = nw / 2;
    ant_d = N;
    buildTab();
    setTab();
}

Engine :: ~Engine()
{
    if (tab)
    {
        for (int i = 0; i < nk; ++i) {
            delete[] tab[i];
        }
        delete[] tab;
        tab = NULL;
    }
    /*if (temp)
    {
        for (int i = 0; i < nk; ++i) {
            delete[] temp[i];
        }
        delete[] temp;
        temp = NULL;
    }*/

}; 

void Engine :: buildTab()
{
    int nk = this->nk;
    int nw = this->nw;
    this->tab = new bool* [nk];
    //this->temp = new bool* [nk];
    for (int i = 0; i < nk; i++)
    {
        tab[i] = new bool[nw];
        //temp[i] = new bool[nw];
    }
}

void Engine :: setTab()
{
    for (int i = 0; i < nk; i++)
    {
        for (int j = 0; j < nw; j++)
        {
            tab[i][j] = 0;
            //temp[i][j] = 0;
        }
        cout << endl;
    }
}

void Engine :: turn_right()
{
    //w prawo
    switch (ant_d)
    {
    case N:
        ant_d = E;
        break;
    case E:
        ant_d = S;
        break;
    case S:
        ant_d = W;
        break;
    case W:
        ant_d = N;
        break;
    }

}

void Engine :: turn_left()
{
    //w lewo
    switch (ant_d)
    {
    case N:
        ant_d = W;
        break;
    case E:
        ant_d = N;
        break;
    case S:
        ant_d = E;
        break;
    case W:
        ant_d = S;
        break;
    }
}

void Engine :: move_forward()
{
    switch (ant_d)
    {
    case N:
        if (ant_pos_y == nw - 1) { ant_pos_y = 0; }
        else { ant_pos_y++; }
        break;
    case E:
        if (ant_pos_x == nk - 1) { ant_pos_x = 0; }
        else { ant_pos_x++; }
        break;
    case S:
        if (ant_pos_y == 0) { ant_pos_y = nw - 1; }
        else { ant_pos_y--; }
        break;
    case W:
        if (ant_pos_x == 0) { ant_pos_x = nk - 1; }
        else { ant_pos_x--; }
        break;
    }
}

void Engine :: move()
{
    move_forward();
    bool pole = tab[ant_pos_x][ant_pos_y];
    //bialy = 0 w lewo
    //czarny = 1 w prawo
    if (pole)
    {
        turn_right();
    }
    else
    {
        turn_left();
    }

}


void Engine :: switch_color(int x, int y)
{
    if (tab[x][y])
    {
        tab[x][y] = false;
    }
    else
    {
        tab[x][y] = true;
    }
}

void Engine :: analyse()
{
    int x = ant_pos_x;
    int y = ant_pos_y;

    //najpierw analizuje kolor i po przejsciu zmienia kolor poprzedniego pola
    move();
    switch_color(x, y);

}