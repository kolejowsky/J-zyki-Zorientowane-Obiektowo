#ifndef GAMETXT_H
#define GAMETXT_H

#include "game.h"

class GameTxt : public Game {
protected:
    void show();
    void view();
public:
    GameTxt() :Game() {};
    GameTxt(int w, int k) :Game(w, k) {};
    ~GameTxt();
private:
    GameTxt(GameTxt& g);
    GameTxt& operator=(const GameTxt& g);
};

#endif

