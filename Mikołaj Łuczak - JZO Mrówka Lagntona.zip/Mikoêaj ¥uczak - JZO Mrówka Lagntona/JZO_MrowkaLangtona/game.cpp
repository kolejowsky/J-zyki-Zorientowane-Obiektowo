#include "game.h"

void Game::view() {};

void Game :: play()
{
    for (int i = 0; i < 14000; i++)
    {
        //cout<<i<<endl;
        analyse();
        view();
    }
}

void Game::timelapse()
{
    for (int i = 0; i < 14000; i++)
    {
        //wyswietlanie timelapsu
        analyse();
        if (i % 100 == 0)
        {
            //cout << i << endl;
            view();
        }
    }
}

Game :: ~Game() {};

