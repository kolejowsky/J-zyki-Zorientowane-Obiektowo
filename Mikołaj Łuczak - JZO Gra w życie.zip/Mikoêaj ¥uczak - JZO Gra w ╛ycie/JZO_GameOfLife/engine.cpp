#include "engine.h"
#include <iostream>
#include <vector>
#include <math.h>
#include <windows.h>
#include <time.h>
#include <fstream>

using namespace std;

    Engine::Engine()
    {
        nk = 10;
        nw = 10;
        buildTab();
        setTab();
    }
    Engine::Engine(int w, int k)
    {
        nk = k;
        nw = w;

        buildTab();
        setTab();
    }
    Engine::~Engine()
    {
        if (tab)
        {
            for (int i = 0; i < nk; ++i) {
                delete[] tab[i];
            }
            delete[] tab;
            tab = NULL;
        }
        if (temp)
        {
            for (int i = 0; i < nk; ++i) {
                delete[] temp[i];
            }
            delete[] temp;
            temp = NULL;
        }

    };

   void Engine::buildTab()
    {
        int nk = this->nk;
        int nw = this->nw;
        this->tab = new bool* [nk];
        this->temp = new bool* [nk];
        for (int i = 0; i < nk; i++)
        {
            tab[i] = new bool[nw];
            temp[i] = new bool[nw];
        }
    }

    void Engine::setTab()
    {
        for (int i = 0; i < nk; i++)
        {
            for (int j = 0; j < nw; j++)
            {
                tab[i][j] = 0;
                temp[i][j] = 0;
            }
            cout << endl;
        }
    }

    //wczytywanie zywych komorek z klawiatury
    void Engine::init()
    {
        int a, b;

        do
        {
            cin >> a;
            cin >> b;
            for (int i = 0; i < nk; i++)
            {
                for (int j = 0; j < nw; j++)
                {
                    if ((i + 1) == a && (j + 1) == b)
                        tab[i][j] = true;
                }
            }
        } while ((a != -1) && (b != -1));
    }

    //czytanie wspolrzednych zywych komorek z pliku
    void Engine::init(char* filename)
    {
        ifstream plik(filename);
        while (plik.good())
        {
            int a, b;
            plik >> a >> b;
            tab[a][b] = 1;
            tab[b][b] = 1;
        }
        plik.close();
    }

    int Engine::checkNeighbours(int i, int j)
    {
        int pom = 0;
        //zmienne pomocnicze ktore w przypadku wartosci na granicy tablicy
        //przyjma wartosc wspolrzednych drugiego konca tej tablic
        int k1, k2, l1, l2;
        if (i == 0) k1 = nk - 1;
        else k1 = i - 1;
        if (i == nk - 1) k2 = 0;
        else k2 = i + 1;
        if (j == 0) l1 = nw - 1;
        else l1 = j - 1;
        if (i == nw - 1) l2 = 0;
        else l2 = j + 1;

        //nad komorka
        if (tab[k1][l1] == 1) pom++;
        if (tab[i][l1] == 1) pom++;
        if (tab[k2][l1] == 1) pom++;
        //tam gdzie komorka
        if (tab[k1][j] == 1) pom++;
        if (tab[k2][j] == 1) pom++;
        //pod komorka
        if (tab[k1][l2] == 1) pom++;
        if (tab[i][l2] == 1) pom++;
        if (tab[k2][l2] == 1) pom++;
        //zwrocenie informacji o ilosci sasiadow
        return pom;
    }

    bool Engine::newStatus(int i, int j)
    {
        //ustalanie nowego statusu kom�rki na podstawie regu� gry i przy u�yciu metody checkNeighbours
        int pom = checkNeighbours(i, j);
        if (tab[i][j] == 0)
        {
            if (pom == 3)
            {
                return 1;
            }
            return 0;
        }
        else
        {
            if (pom == 2 || pom == 3)
            {
                return 1;
            }
            else return 0;
        }
    }

    void Engine::analyze()
    {
        for (int i = 0; i < nk; i++)
        {
            for (int j = 0; j < nw; j++)
            {
                temp[i][j] = newStatus(i, j);
            }
        }
    }
