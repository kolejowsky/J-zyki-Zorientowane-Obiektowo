#ifndef ENGINE_H
#define ENGINE_H

class Engine
{
protected:
    bool** tab;
    bool** temp;
    int nk, nw;
    //protected:
public:
    Engine();
    Engine(int w, int k);
    ~Engine();
    void buildTab();
    void setTab();
    void init();
    void init(char* filename);
    void analyze();
    //private:
    int checkNeighbours(int i, int j);
    bool newStatus(int i, int j);

private:
    Engine(const Engine& e);
    Engine& operator= (const Engine& e);

};

#endif
