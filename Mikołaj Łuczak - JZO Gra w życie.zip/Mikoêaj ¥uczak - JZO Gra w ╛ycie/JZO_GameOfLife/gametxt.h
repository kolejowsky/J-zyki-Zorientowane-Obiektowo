#ifndef GAMETXT_H
#define GAMETXT_H

#include "gameoflife.h"

class GameTxt : public GameOfLife {
protected:
private:
    GameTxt(GameTxt& g);
    GameTxt& operator=(const GameTxt& g);
public:
    GameTxt() :GameOfLife() {};
    void showTab();
    void view(char* filename);
    void view();
    ~GameTxt();
};

#endif
