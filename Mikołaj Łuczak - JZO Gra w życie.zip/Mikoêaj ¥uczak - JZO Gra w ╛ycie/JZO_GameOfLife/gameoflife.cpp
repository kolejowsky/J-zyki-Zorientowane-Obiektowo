#include <iostream>
#include <vector>
#include <math.h>
#include <windows.h>
#include <time.h>
#include <fstream>

#include "gameoflife.h"

using namespace std;

void GameOfLife::play()
{

    //tworzenie kolejnej tury
    for (int i = 0; i < nk; i++)
    {
        for (int j = 0; j < nw; j++)
        {
            temp[i][j] = newStatus(i, j);
        }
    }
    //przepisywanie tury do tablicy g��wnej
    for (int i = 0; i < nk; i++)
    {
        for (int j = 0; j < nw; j++)
        {
            tab[i][j] = temp[i][j];
        }
    }

}

GameOfLife::~GameOfLife() {};
void GameOfLife::view() {};
