#include <iostream>
#include "gametxt.h"

using namespace std;


int main()
{
    // czytanie z pliku
    char name[10] = "wsp.txt";
    GameTxt g1;
    g1.view(name);
    return 0;
}



