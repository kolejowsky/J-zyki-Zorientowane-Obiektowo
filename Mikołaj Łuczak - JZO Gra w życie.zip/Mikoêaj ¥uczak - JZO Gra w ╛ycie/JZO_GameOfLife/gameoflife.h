#ifndef GAMEOFLIFE_H
#define GAMEOFLIFE_H

#include "engine.h"

class GameOfLife : public Engine
{
public:
    //protected:
    GameOfLife() :Engine(){};
    void play();
    virtual void showTab()=0;
private:
    GameOfLife(const GameOfLife& g);
    GameOfLife& operator= (const GameOfLife& g);
public:
    ~GameOfLife();
    void view();
};

#endif
