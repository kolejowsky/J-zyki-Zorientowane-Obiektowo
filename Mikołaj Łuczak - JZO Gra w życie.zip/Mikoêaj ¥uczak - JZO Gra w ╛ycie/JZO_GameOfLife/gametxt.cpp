#include <iostream>
#include <vector>
#include <math.h>
#include <windows.h>
#include <time.h>
#include <fstream>

#include "gametxt.h"

using namespace std;

void GameTxt::showTab()
{
    //funkcja pomocnicza
    for (int i = 0; i < nk; i++)
    {
        for (int j = 0; j < nw; j++)
        {
            cout << tab[i][j] << " ";
        }
        cout << endl;
    }
}

void GameTxt:: view(char* filename)
{
    //wersja z wczytywaniem z klawiatury
    init(filename);
    while (true)
    {
        play();
        showTab();
        Sleep(500);
        system("cls");
    }
}

void GameTxt::view()
{
    //wersja z wpisywaniem z klawiatury
    init();
    while (true)
    {
        play();
        showTab();
        Sleep(500);
        system("cls");
    }
}

GameTxt::~GameTxt() {};
